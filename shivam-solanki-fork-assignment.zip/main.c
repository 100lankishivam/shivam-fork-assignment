#include<stdio.h>
#include<unistd.h>
#include<sys/wait.h>
 
int main()
{   int f1 = fork();
    int f2 = fork();
     if (f1 > 0 && f2 > 0) {
        printf("parent\n");
        printf("%d %d \n", f1, f2);
        printf(" my id is %d \n", getpid());
        sleep(7);}
    
    else if (f1 == 0 && f2 > 0){
      printf("First child\n");
        printf("%d %d \n", f1, f2);
        printf("my id is %d  \n", getpid());}
    
    else if (f1 > 0 && f2 == 0)
   {sleep(5);
        printf("Second child\n");
        printf("%d %d \n", f1, f2);
        printf("my id is %d  \n", getpid());}
     
     else { sleep(6);
        printf("third child\n");
        printf("%d %d \n", f1, f2);
        printf(" my id is %d \n", getpid());}
    
    sleep(9);
    
    if (f1 > 0 && f2 > 0) {
        printf("parent\n");
        printf("%d %d \n", f1, f2);
        printf(" my id is %d \n", getpid());
        sleep(12);}
    else if (f1 == 0 && f2 > 0)
     {
        printf("First child\n");
        kill(getpid(),0);
         printf("killed 1st child ..its ppid=%d \n", getpid());
     }
    else if (f1 > 0 && f2 == 0)
    
    {sleep(7);
        printf("Second child\n");
        printf("%d %d \n", f1, f2);
        printf("my id is %d  \n", getpid()); 
        printf("my parent id is %d \n",getppid());}
    else {
        sleep(10);
        printf("third child\n");
        printf("%d %d \n", f1, f2);
        printf(" my id is %d \n", getpid());
        printf("my parent id is %d \n", getppid());
    }
    return 0;
}

